# ext-theme-base/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-theme-base/sass/etc"`, these files
need to be used explicitly.
